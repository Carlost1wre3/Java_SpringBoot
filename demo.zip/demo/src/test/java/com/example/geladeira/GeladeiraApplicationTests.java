package com.example.geladeira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeladeiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
