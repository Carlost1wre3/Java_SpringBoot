package com.example.geladeira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeladeiraApplication {

	public static void main(String[] args) {

		SpringApplication.run(GeladeiraApplication.class, args);
	}

}
